# Regular Expressions with Literal Characters and Character Types

## Instructions

* Load in the "Alice in Wonderland" text into a DataFrame `alice_df`.

* Create regular expression patterns to find all lines that 

    * contain the string `cat`,
    * contain the string ` cat` (beginning with a space),
    * contain the string ` cat` beginning with a space and ending with a non-word character.